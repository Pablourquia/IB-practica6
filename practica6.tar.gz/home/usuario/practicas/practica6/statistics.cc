#include <iostream>
#include <vector>
using namespace std;

int main(){
  vector <double> numbers;
  int kVectorSize{4};
  double minimum_value = 10;
  double maximum_value = 0;
  double sum = (0.0);
  srand(time(NULL));
  for (int i = 0; i<= kVectorSize; i++){
    double random_number = rand() % 10;
    numbers.push_back(random_number);
    if (numbers[i] > maximum_value){
      maximum_value = numbers[i];
}
    if (numbers[i] < minimum_value){
      minimum_value = numbers[i];
} 
   
    sum = sum + numbers[i];
   
}
  cout << "La media de los tres numeros aleatorios es " << sum/kVectorSize << endl;
  cout << "El valor maximo es " << maximum_value << endl;
  cout << "El valor minimo es " << minimum_value << endl;
  return 0;
}
